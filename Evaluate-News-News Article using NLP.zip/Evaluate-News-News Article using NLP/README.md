## Evaluate News Articles using NLP##
an application that analys news articles using anatural language prossessing

## Features: 
 * Sentiment Analysist : using natural language to process news articles and blogs ...
 * Content Evalution : automaticly calculates and analys text of news articles and blogs readability and quality.


## Requirment 
* node.js 
* express.js
* webpack 
* any text editor

## Getting Start 

1- install node.js in your pc

2- open the project via editor .

3- install node_modules via command npm install 

4- install webpack via command , npm webpack.

5- once you install all, run the server via npm start.

6- create dist folder with command , npm run build-prod .

7 now you are all sett in browser paste the page or article r text in field and click submit .


# LICENCE 

* This project is licenced under udactity.com