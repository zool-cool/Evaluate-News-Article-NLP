const { handleSubmit } = require("../views/js/handleSubmit")

describe('handleSubmit', ()=> {
    it('returns url,text', () => {
        expect(handleSubmit).toBeDefined();
    })
})
