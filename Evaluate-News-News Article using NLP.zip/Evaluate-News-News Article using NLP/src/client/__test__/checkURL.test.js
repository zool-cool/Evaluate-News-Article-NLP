const { isValidUrl } = require("../views/js/checkURL")

describe('urlinValid', ()=> {
    test('check if text != url', () => {
        expect(isValidUrl("not")).toBeFalsy();
    })
    
    test('check if text = email', () => {
        expect(isValidUrl("Example :saber@gmail.com")).toBeFalsy();
    })
    
    test('check if text = url ', () => {
        expect(isValidUrl("https://www.facebook.com")).toBeTruthy();
    })

})

