import("./views/styles/style.scss")
import { handleSubmit } from "./views/js/handleSubmit"


export { handleSubmit }