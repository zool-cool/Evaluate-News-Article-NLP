 const meaningCloud = "https://api.meaningcloud.com/sentiment-2.1"
const axios = require("axios")


const analyze = async (url, key) => {

    const analysis = await axios.get(`${meaningCloud}?key=${key}&url=${url}&lang=en`)
        .then(function (response) {
            const { code } = response.data.status
            
            if (code == 100) {
                const error = handleError(code, "please enter a valid URL")
                return error
            } else if (code == 212) {
                const error = handleError(code, response.data.status.msg)
                return error
            }
            return successResponse(response.data, code)
        })
    return analysis
}

const handleError = (code, msg) => {
    const error = {
        code: code,
        msg: msg
    }
    return error
}

const successResponse = (data, code) =>{
    const { score_tag, agreement, subjectivity, confidence, irony } = data
            let sample = {

                agreement: agreement,
                subjectivity: subjectivity,
                confidence: confidence,
                irony: irony
            }
            const result = { sample, status: code }
            console.log(successResponse);
            return result
}
module.exports = {
    analyze
}